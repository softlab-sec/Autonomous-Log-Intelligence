#!/bin/bash
# Generates sudo failures and su events
# Events appear in /var/log/auth.log

echo "[*] Generating privilege escalation events..."

for i in {1..5}; do
  echo "wrongpassword" | sudo -S id 2>/dev/null || true
  sleep 0.5
done

# One valid sudo so there's context contrast
sudo id

echo "[*] Done. Verify with: sudo tail -20 /var/log/auth.log"
